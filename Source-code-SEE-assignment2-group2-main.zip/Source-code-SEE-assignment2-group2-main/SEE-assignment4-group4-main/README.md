# SEE-assignment4

phần mềm minh họa/trợ giúp thực hiện quy trình xây dựng dự toán phần mềm theo công văn 2589

# Các thông tin chung

- Nhóm:2


- Ngôn ngữ sử dụng: Javascript + ReactJs
