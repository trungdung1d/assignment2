import { useState } from "react";

const UUCPComponent = () => {
	const [taw, setTaw] = useState(0);
	const [tbf, setTbf] = useState(0);
	return <div>test</div>;
};

export default UUCPComponent;
